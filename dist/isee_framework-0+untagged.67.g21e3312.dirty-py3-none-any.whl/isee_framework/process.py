"""
This portion of the program is responsible for handling setup of the appropriate batch script(s) for the next step in a
Thread, passing them to a task manager to submit them, and updating the list of currently running threads accordingly.
"""

import jinja2
import os
import sys
import math
import time
import pickle
import shutil
import pathlib
import warnings
from isee_framework.infrastructure import factory

def process(thread, running, allthreads, settings, inp_override=''):
    """
    Reads the thread to identify the next step, then builds and returns the batch file(s).

    Parameters
    ----------
    thread : Thread()
        The Thread object on which to act
    running : list
        The list of currently running threads, which will be updated as needed
    allthreads : list
        List of all extant threads, running or not
    settings : argparse.Namespace
        Settings namespace object
    inp_override : str
        Specified input file to use in place of the one from jobtype.get_input_file (used by initialize_charges.py)

    Returns
    -------
    running : list
        The updated list of currently running threads after this process step

    """

    # First, check if the previous call to jobtype.algorithm flagged an 'IDLE' step, and if so, skip processing
    if thread.idle:
        if thread not in running:   # idle threads are still running
            running.append(thread)
        return running

    # Determine next step and, if appropriate, build corresponding list of batch files
    if not thread.skip_update:
        thread.current_name = thread.get_next_step(settings)
    else:
        thread.skip_update = False

    if thread.terminated:
        if thread in running:
            running.remove(thread)
            if running is None:
                running = []       # to keep running as a list, even if empty
        return running

    batchfiles = []         # initialize list of batch files to submit
    jobtype = factory.jobtype_factory(settings.job_type)    # get jobtype for calling jobtype.update_history
    this_inpcrd, this_top = jobtype.get_struct(thread)
    name = thread.current_name
    threadis = [allthreads.index(thread)]

    if not inp_override:
        (inps) = jobtype.get_input_file(thread, settings)
    else:
        (inps) = inp_override

    inp = inps[0]
    try:
        heat_inp = inps[1]
    except IndexError:
        heat_inp = None
    try:
        min_inp = inps[2]
    except IndexError:
        min_inp = None

    # Point to the copy of isee_titrate co-located in the directory containing this file
    isee_titrate_path = pathlib.Path(__file__).parent.resolve() + '/' + 'isee_titrate.py'

    if settings.degeneracy and not name == 'ic':
        degeneracy = ['_' + str(ii) for ii in range(settings.degeneracy)]
    else:
        degeneracy = ['']

    for degen in degeneracy:
        template = settings.env.get_template(thread.get_batch_template(settings))

        these_kwargs = { 'name': thread.name + '_' + name + degen,
                         'nodes': eval('settings.nodes'),
                         'taskspernode': eval('settings.ppn'),
                         'walltime': eval('settings.walltime'),
                         'mem': eval('settings.mem'),
                         'solver': eval('settings.solver'),
                         'inp': inp,
                         'out': thread.name + '_' + name + degen + '.out',
                         'prmtop': this_top,
                         'inpcrd': this_inpcrd,
                         'rst': thread.name + '_' + name + degen + '.rst7',
                         'nc': thread.name + '_' + name + degen + '.nc',
                         'working_directory': settings.working_directory,
                         'extra': eval(settings.extra),
                         'degen': degen,
                         'mps': '{{ mps }}',
                         'min_inp': min_inp,
                         'heat_inp': heat_inp,
                         'isee_titrate': isee_titrate_path}

        filled = template.render(these_kwargs)
        newfilename = thread.name + '_' + name + degen + '.' + settings.batch_system
        try:
            with open(newfilename, 'w') as newfile:
                newfile.write(filled)
                newfile.close()
        except OSError as e:
            if 'name too long' in str(e):
                raise RuntimeError('Encountered too-long filename: ' + newfilename + '. You can avoid this by setting'
                                   'name_as_timestamp = True in the config file.')
            else:
                raise e

        batchfiles.append(newfilename)
        jobtype.update_history(thread, settings, **these_kwargs)

    # Support for NVIDIA MPS
    if settings.nvidia_mps > 1:
        # Write names of batchfiles to temporary 'queue' file to track while awaiting submission
        if not os.path.exists('mps_batchqueue.temp'):
            open('mps_batchqueue.temp', 'w').close()
        with open('mps_batchqueue.temp', 'a') as f:
            for batchfile in batchfiles:
                f.write(batchfile + '\t' + str(allthreads.index(thread)) + '\n')

        readlines = open('mps_batchqueue.temp').readlines()
        if settings.nvidia_mps > 1 and (not settings.mps_patient or len(readlines) >= settings.nvidia_mps):
            # Pull batch file names out of the temporary queue file to prepare to submit
            n_tosubmit = len(readlines) - (len(readlines) % settings.nvidia_mps)    # number of filenames to pull out
            tosubmit = [line.split()[0] for line in readlines[:n_tosubmit]]
            threadis = [int(line.split()[1]) for line in readlines[:n_tosubmit]]
            try:
                assert all([os.path.exists(file) for file in tosubmit])
            except AssertionError:
                raise RuntimeError('Attempted to submit one or more files from mps_batchqueue.temp and found they did '
                                   'not exist. If you are seeing this message, try manually deleting that temp file '
                                   'and restarting isEE (this may skip some steps, depending the algorithm setting)')
            open('mps_batchqueue.temp', 'w').write(''.join(readlines[n_tosubmit:]))     # remove pulled lines from file

            # Call mps_combine on pulled batch file names
            batchfiles = mps_combine(tosubmit, settings)
            for batchfile in tosubmit:  # clean up the original batch files
                os.remove(batchfile)
        elif settings.mps_patient and len(readlines) < settings.nvidia_mps:
            # Not ready to move forward yet, so just prepare running and return
            if thread not in running:   # the thread is still "running" while its jobs are in the queue file
                running.append(thread)
            thread.mps_idle = True	# but it's idle for now!
            return running

    # Prepare task manager to submit batch files to
    taskmanager = factory.taskmanager_factory(settings.task_manager)
    for threadi in threadis:
        this_thread = allthreads[threadi]
        this_thread.jobids = []      # to clear out previous jobids if any exist

    # Do job submission and handle storing returned jobids within threads
    if settings.nvidia_mps > 1:
        jobids = []
        for file in batchfiles:
            jobids.append(taskmanager.submit_batch(file, settings))
        assert len(jobids) > 0

        # Duplicate jobids as appropriate
        for threadi in threadis:
            this_thread = allthreads[threadi]
            jobids = sum([[jobid for _ in range(settings.nvidia_mps)] for jobid in jobids], [])[:len(this_thread.current_type)]
            this_thread.jobids = jobids
            this_thread.mps_idle = False
            assert len(jobids) > 0
    else:
        for file in batchfiles:
            thread.jobids.append(taskmanager.submit_batch(file, settings))

    # Dump restart.pkl with updates from process (if allthreads was passed)
    if allthreads:
        pickle.dump(allthreads, open('restart.pkl.bak', 'wb'))  # if the code crashes while dumping it could delete the contents of the pkl file
        if not os.path.getsize('restart.pkl.bak') == 0:
            shutil.copy('restart.pkl.bak', 'restart.pkl')       # copying after is safer

    if thread not in running:
        running.append(thread)
    return running

def mps_combine(batchfiles, settings):
    """
    Create new batch files by combining the files in batchfiles in chunks of settings.nvidia_mps. Also fill the
    {{ mps }} slot with a unique identifier.

    Does not add necessary lines to the batch files for spinning up an MPS daemon (or closing one). These lines must be
    present in the batch file template.

    Parameters
    ----------
    batchfiles : list
        List of strings, filenames of batch files to combine
    settings : argparse.Namespace
        Settings namespace object

    Returns
    -------
    combined : list
        List of strings, filename of newly created combined batch files

    """

    # Get lines of each file as a list of lists, ensure length parity
    lines = [open(file, 'r').readlines() for file in batchfiles]
    try:
        assert all([len(item) == len(lines[0]) for item in lines])
    except AssertionError:
        raise RuntimeError('Attempted to combine files for NVIDIA MPS, but they are not all of the same number of '
                           'lines. Offending files are: ' + str(batchfiles))

    combined_file_count = math.floor(len(batchfiles) / settings.nvidia_mps)     # number of fully combined files to make
    mod = len(batchfiles) % settings.nvidia_mps     # number of leftover files to fit into last combined file
    if mod:
        if_mod = 1
    else:
        if_mod = 0

    # Get batchsystem for future reference
    batchsystem = factory.batchsystem_factory(settings.batch_system)

    # Initialize list of files to return
    to_return = []

    # Build each new file with a loop
    for ii in range(combined_file_count + if_mod):
        # Set unique identifier for MPS system based on current system time
        uniqid = str(time.time())
        print('uniqid: ' + uniqid)

        # Determine subset of files to combine in this loop
        try:
            files = batchfiles[ii * settings.nvidia_mps : (ii + 1) * settings.nvidia_mps]
        except IndexError:  # leftover files
            files = batchfiles[ii * settings.nvidia_mps :]

        # Combine them by iterating through lines
        newfilename = files[0] + '_mps.' + settings.batch_system
        open(newfilename, 'w').close()
        with open(newfilename, 'a') as f:
            lines = [open(file, 'r').readlines() for file in files]
            for jj in range(len(lines[0])):     # if an ignore_string is present, write without modifying
                if any([ignore_string in lines[0][jj] for ignore_string in batchsystem.mps_ignore_strings()]):
                    f.write(lines[0][jj].replace('{{ mps }}', uniqid))
                elif len(set([lines[kk][jj] for kk in range(len(lines))])) == 1:    # elif all lines at this position are the same
                    f.write(lines[0][jj].replace('{{ mps }}', uniqid))
                else:   # neither of the above, so combine with ampersands to parallelize with MPS
                    joined = ' & '.join([lines[kk][jj].replace('\n', '') for kk in range(len(lines))]) + '\n'
                    f.write(joined.replace('{{ mps }}', uniqid))

        to_return.append(newfilename)

    return to_return